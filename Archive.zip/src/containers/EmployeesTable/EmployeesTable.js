import React, { Component } from 'react';
import { Table } from 'react-bootstrap';
import axios from 'axios';

import EmployeeRow from '../../components/EmployeeRow/EmployeeRow';

export class EmployeesTable extends Component {
  state = {
    employees: []
  };
  componentDidMount() {
    const axiosInstance = axios.create({
      baseURL: 'https://fourth-js-interview-b392e.firebaseapp.com/employees',
      timeout: 5000,
      headers: {
        Authorization: 'fourth-js-interview-data',
        'Content-Type': 'application/json'
      }
    });

    axiosInstance
      .get()
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      });
  }

  render() {
    const users = this.state.employees.map((employees, i) => {
      const { id, username, name, email } = employees;
      return (
        <EmployeeRow key={id} name={name} username={username} email={email} />
      );
    });
    return (
      <Table striped bordered condensed>
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>{users}</tbody>
      </Table>
    );
  }
}

export default EmployeesTable;
