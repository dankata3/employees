import React, { Component } from 'react';
import './App.css';
import EmployeesTable from './containers/EmployeesTable/EmployeesTable';

class App extends Component {
  render() {
    return (
      <div className="App">
        <EmployeesTable />
      </div>
    );
  }
}

export default App;
