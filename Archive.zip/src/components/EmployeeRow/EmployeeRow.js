import React from 'react';

const employeeRow = props => {
  const { id, name, username, email } = props;
  return (
    <tr key={id}>
      <td>{id}</td>
      <td>{name}</td>
      <td>{username}</td>
      <td>{email}</td>
    </tr>
  );
};

export default employeeRow;
